/*SQL Query 1*/

SELECT 
	SUM(CASE WHEN c.category = 'German' THEN 1 ELSE 0 END) German, 
	SUM(CASE WHEN c.category = 'American' THEN 1 ELSE 0 END) American,
	SUM(CASE WHEN c.category = 'Japanese' THEN 1 ELSE 0 END) Japanese 
FROM Sellers s1 INNER JOIN 
	cars c ON s1.car = c.car 
WHERE s1.selling_date >= '2006-01-01' AND s1.selling_date <= '2006-12-31'
	AND (s1.price > (SELECT AVG(price) FROM sellers s2 WHERE s2.car = c.car))

/*SQL Query 2*/

SELECT top_sellers.first_name,
		top_sellers.last_name,
		top_sellers.car,
		top_sellers.category,
		top_sellers.region,
		top_sellers.selling_date,
		top_sellers.price 
FROM (
		SELECT s.first_name, s.last_name,s.car,c.category,r.region, s.selling_date,s.price,
				ROW_NUMBER() OVER (PARTITION BY r.region ORDER BY s.price DESC) AS rn
		FROM sellers s INNER JOIN
			cars c ON s.car = c.car INNER JOIN
			regions r ON s.region_id = r.region_id
		WHERE s.selling_date >= '2006-01-01' 
			AND s.selling_date <= '2006-12-31'
			AND (c.category = 'German' OR c.category = 'American' OR c.category = 'Japanese')
	) top_sellers WHERE rn <= 7
